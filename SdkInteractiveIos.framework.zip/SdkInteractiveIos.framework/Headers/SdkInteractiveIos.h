//
//  SdkInteractiveIos.h
//  SdkInteractiveIos
//
//  Created by Minh Vu on 19/12/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for SdkInteractiveIos.
FOUNDATION_EXPORT double SdkInteractiveIosVersionNumber;

//! Project version string for SdkInteractiveIos.
FOUNDATION_EXPORT const unsigned char SdkInteractiveIosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SdkInteractiveIos/PublicHeader.h>


